const $ = (id) => document.getElementById(id);
$('year').textContent = new Date().getFullYear();

const menuToggle = $('menuToggle');
const mainNav = $('mainNav');
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mainNav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

$('rpmForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const speed = Number($('speed').value);
  const tire = Number($('tire').value);
  const axle = Number($('axle').value);
  const trans = Number($('trans').value);
  if (![speed,tire,axle,trans].every(Number.isFinite) || speed <= 0 || tire <= 0 || axle <= 0 || trans <= 0) return;
  const rpm = Math.round((speed * axle * trans * 336) / tire);
  $('rpmResult').innerHTML = `<span>ESTIMATED ENGINE SPEED</span><strong>${rpm.toLocaleString()} RPM</strong><small>At ${speed} MPH, with ${tire}" tires and ${axle.toFixed(2)} axle gears.</small>`;
});

$('budgetForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const parts = Number($('partsCost').value);
  const labor = Number($('laborCost').value);
  const buffer = Number($('buffer').value);
  if (![parts,labor,buffer].every(Number.isFinite) || parts < 0 || labor < 0 || buffer < 0 || buffer > 100) return;
  const subtotal = parts + labor;
  const total = subtotal * (1 + buffer / 100);
  $('budgetResult').innerHTML = `<span>PLANNED PROJECT TOTAL</span><strong>${total.toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0})}</strong><small>Subtotal ${subtotal.toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0})} + ${buffer}% contingency.</small>`;
});

$('tireForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const oldTire = Number($('oldTire').value);
  const newTire = Number($('newTire').value);
  const indicated = Number($('indicated').value);
  if (![oldTire,newTire,indicated].every(Number.isFinite) || oldTire <= 0 || newTire <= 0 || indicated <= 0) return;
  const actual = indicated * newTire / oldTire;
  const change = ((newTire / oldTire) - 1) * 100;
  $('tireResult').innerHTML = `<span>ESTIMATED ACTUAL SPEED</span><strong>${actual.toFixed(1)} MPH</strong><small>Tire diameter changes ${change >= 0 ? '+' : ''}${change.toFixed(1)}%. Recalibrate/verify your speedometer.</small>`;
});

$('newsletterForm').addEventListener('submit', (event) => {
  event.preventDefault();
  $('newsletterMessage').textContent = 'This is a demo and has not saved your email. Connect a mailing-list provider before launch.';
});
