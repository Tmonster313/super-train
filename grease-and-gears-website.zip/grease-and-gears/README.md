# Grease & Gears Garage

A responsive static website starter for an automotive / truck DIY content business. It includes:
- Responsive landing page with custom CSS/SVG artwork
- RPM / gearing calculator
- Build budget calculator
- Tire-size comparison calculator
- Three starter educational guides
- Downloadable build-planner CSV
- Affiliate disclosure, privacy policy, and contact placeholders

## Run locally
Open `index.html` in a browser. No build step or paid software is required.

## Publish for free with GitHub Pages
1. Create a GitHub account at https://github.com/ if you don't have one.
2. Create a **public** repository (for example `grease-and-gears`).
3. Upload the contents of this folder to the repository root. `index.html` must be at the root.
4. In the repository, open **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. The Pages screen shows the published URL.
7. Test the site on phone and desktop, and click every download and navigation link.

GitHub's menus can change; use its current Pages documentation if the labels differ:
https://docs.github.com/pages

## Before launch
- Replace the demo newsletter behavior with a real mailing-list service and a working consent process. The current form does not collect or send emails.
- Add a real contact email or working contact form.
- Review and adapt `privacy.html` and `disclosure.html` to reflect the actual services you use. These are starter templates, not legal advice.
- Add your own original photos, build experience, measurements, sources, and specific vehicle fitment notes. Do not publish generic content as if you personally tested a product.
- Test calculator outputs against trusted examples and include a clear note that they are estimates.
- Add analytics only if you want them, and update your privacy disclosures accordingly.
- Add affiliate links only after approval by the relevant programs. Disclose the relationship clearly near each link, e.g. “We may earn a commission if you buy through this link, at no extra cost to you.”
- Check all pages for typos, accessibility, mobile layout, and working links.

## Monetization plan (no upfront spend)
1. **Affiliate links:** Apply to suitable parts/tool programs (for example, Amazon Associates or direct retailer programs). Approval and eligibility vary. Don't add affiliate links until accepted and always follow each program's current rules.
2. **Digital downloads:** Start with the included CSV, then build genuinely useful premium resources such as a vehicle-specific maintenance tracker, engine-build budget workbook, towing pre-trip checklist, or project parts tracker. Offer a useful free sample and sell expanded versions through a platform that supports your location and terms. A platform may deduct transaction fees; $0 upfront does not mean zero fees.
3. **Search-focused content:** Publish genuinely helpful, original guides aimed at specific questions, such as “how tire diameter affects RPM” or “what to include in an engine rebuild budget.” Cite manufacturer manuals and reliable sources. Search traffic usually takes time and is not guaranteed.
4. **Email list:** Add a real provider's signup form and send useful updates, not spam. Obtain consent and honor unsubscribe requests.
5. **Improve conversion:** Track which pages people use, add relevant product comparisons, and make the next step clear. Don't invent reviews, ratings, prices, or “tested” claims.

## Important
This starter site is a functional static front end, not a guaranteed income system. It has no active affiliate links, backend, real newsletter capture, payment processing, analytics, or ad network connection. You must connect and configure those services yourself. Earnings are not guaranteed.

Vehicle content is educational only. Confirm fitment, torque specifications, load ratings, towing limits, and legal requirements using official service information and qualified professionals.
